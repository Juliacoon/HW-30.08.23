public class Main {
    public static void main(String[] args) {
        String myChar = ("G");
        int myInt = 89;
        byte myByte = 4;
        short myShort = 56;
        float Myfloat = 4.7333436F;
        double myDouble = 4.355453532;
        long myLong = 12121;







        int abc = 345;
        System.out.println("I can't understand how to do that Homework unfortunately');

    }
}